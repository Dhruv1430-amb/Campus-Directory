jQuery(document).ready(function($){
        $(this).setFeedback(campus_directory_vars.plugin);
});
