jQuery(document).ready(function($) {
$('.emd-yt').lazyYT('AIzaSyA7XB8rClz73BL-hmxOlyZxwlwJpFS8wBg');
});
