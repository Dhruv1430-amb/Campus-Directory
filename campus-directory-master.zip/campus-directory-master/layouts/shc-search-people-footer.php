<?php global $search_people_shc_count; ?></table>
</div>